# SW HNG Project 

# What's new in the latest version

## Version 0.0.1
### New:
1. All new ... ⚡
### Bugs fixed:
1. New release without bugs and problems 🏆
### Notes:
1. The release works as expected