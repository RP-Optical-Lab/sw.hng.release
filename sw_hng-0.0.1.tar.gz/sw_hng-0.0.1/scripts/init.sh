#!/bin/sh

# Script on startup 

prints (){
	echo [hng] $@ | tee /dev/kmsg
}

action () {
	prints $@
	eval $@
	if [ $? -ne 0 ]; then
		prints Command failed!
		exit 1
	fi
}

prints Start Init script
action sleep 5 # Take a break while loading a FPGA Bitstream
prints Start Application
action /home/max/sw.hng/sw_hng-0.0.1/hng params.json
