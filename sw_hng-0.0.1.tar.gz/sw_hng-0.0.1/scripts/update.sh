#!/bin/bash

prints (){
	echo [hng-upd] $@ | tee /dev/kmsg
}

action () {
	prints $@
	eval $@
	if [ $? -ne 0 ]; then
		prints Command failed!
		exit 1
	fi
}

if [ "$#" -ne 2 ]; then
    prints	Nothing to do...
    exit 1
fi

FILE="$1"
FILENAME="$(basename "$FILE" .tar.gz)"
SW_DIR="/home/max/sw.hng"
SCR_DIR="$SW_DIR/scripts"
prints  Update $FILENAME

if [ $2 -eq 0 ]; then
    action  tar xvf $FILE -C /lib/firmware/xilinx
    action  'echo '$FILENAME' | tee /etc/dfx-mgrd/'$FILENAME''
    action  ln -sf /etc/dfx-mgrd/$FILENAME /etc/dfx-mgrd/default_firmware
elif [ $2 -eq 1 ]; then
    action  tar xvf $FILE -C $SW_DIR
    action  cp $SW_DIR/$FILENAME/README.md $SW_DIR
    action  cp $SW_DIR/$FILENAME/scripts/init.sh  $SCR_DIR/init.sh
    action  ln -sf $SCR_DIR/init.sh /home/max/sw.swir/scripts/init.sh
else
    prints  Nothing to do...
fi
prints  Done
exit 0